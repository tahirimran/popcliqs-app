<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * Abstract layer for CDN.
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author			Raymond Benc
 * @package 		Phpfox
 * @version 		$Id: abstract.class.php 3956 2012-03-01 12:28:26Z Raymond_Benc $
 * @abstract 
 */
abstract class Phpfox_Cdn_Abstract
{
	public function setServerId($iServerId)
	{
		
	}
}

?>