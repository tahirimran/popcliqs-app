<?php

$this->_upgradeDatabase('2.0.7');
	
$bCompleted = true;

?>