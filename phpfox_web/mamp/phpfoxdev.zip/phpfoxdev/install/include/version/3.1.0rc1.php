<?php

$this->_upgradeDatabase('3.1.0rc1');

$bCompleted = true;

?>