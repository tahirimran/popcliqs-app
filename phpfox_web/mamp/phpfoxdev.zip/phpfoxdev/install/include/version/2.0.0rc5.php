<?php

$this->_upgradeDatabase('2.0.0rc5');

$bCompleted = true;

?>