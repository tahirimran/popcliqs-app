<?php

$this->_upgradeDatabase('2.0.6');
	
$bCompleted = true;

?>