<?php

$this->_upgradeDatabase('2.1.0rc1');
	
$bCompleted = true;

?>