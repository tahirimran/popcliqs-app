<?php

$this->_upgradeDatabase('3.3.0beta1');

$bCompleted = true;

?>