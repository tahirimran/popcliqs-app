<?php

$this->_upgradeDatabase('2.0.0');

$bCompleted = true;

?>