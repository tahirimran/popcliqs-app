<?php

$this->_upgradeDatabase('2.0.2');

$bCompleted = true;

?>