<?php

$this->_upgradeDatabase('2.0.0rc2');

$bCompleted = true;

?>