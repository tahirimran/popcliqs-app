<?php

$this->_upgradeDatabase('2.0.0rc9');

$bCompleted = true;

?>