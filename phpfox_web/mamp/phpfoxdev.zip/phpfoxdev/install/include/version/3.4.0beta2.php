<?php

$this->_upgradeDatabase('3.4.0beta2');

$bCompleted = true;

?>