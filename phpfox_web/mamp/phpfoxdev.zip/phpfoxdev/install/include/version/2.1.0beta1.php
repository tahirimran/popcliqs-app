<?php

$this->_upgradeDatabase('2.1.0beta1');
	
$bCompleted = true;

?>