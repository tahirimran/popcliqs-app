<?php

$this->_upgradeDatabase('3.0.0beta5');

$bCompleted = true;

?>