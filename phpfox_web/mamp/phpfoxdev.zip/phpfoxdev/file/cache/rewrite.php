<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'login' => 
  array (
    'module' => 'user',
    'component' => 'login',
  ),
  'user/login' => 'login',
  'logout' => 
  array (
    'module' => 'user',
    'component' => 'logout',
  ),
  'user/logout' => 'logout',
); ?>