<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  1 => true,
  2 => true,
  3 => true,
  4 => true,
  5 => true,
  6 => true,
); ?>