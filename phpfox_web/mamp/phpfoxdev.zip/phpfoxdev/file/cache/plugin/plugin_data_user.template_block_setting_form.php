<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = 'Phpfox::getBlock(\'music.genre\'); '; ?>