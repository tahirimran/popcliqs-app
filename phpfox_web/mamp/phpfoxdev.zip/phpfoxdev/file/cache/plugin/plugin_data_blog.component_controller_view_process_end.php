<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = '/*
$this->template()
	->setMeta(\'og:title\', $aItem[\'title\'])
	->setMeta(\'og:site_name\', Phpfox::getParam(\'core.site_title\'))
	->setMeta(\'og:image\', \'http://79.136.56.107/phpfox/2x/upload/static/image/misc/noimage_50.png\');
*/ '; ?>