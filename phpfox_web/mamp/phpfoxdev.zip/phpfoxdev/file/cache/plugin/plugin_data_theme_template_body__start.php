<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = ' echo \'<div id="fb-root"></div>\'; '; ?>