<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'phpfox' => 
  array (
    'product_id' => 'phpfox',
    'is_core' => '0',
    'title' => 'Core',
    'description' => '',
    'version' => '',
    'latest_version' => NULL,
    'last_check' => '1368964157',
    'is_active' => '1',
    'url' => '',
    'url_version_check' => '',
  ),
  'phpfox_installer' => 
  array (
    'product_id' => 'phpfox_installer',
    'is_core' => '0',
    'title' => 'Core Installer',
    'description' => '',
    'version' => '1',
    'latest_version' => NULL,
    'last_check' => '1371001267',
    'is_active' => '1',
    'url' => '',
    'url_version_check' => '',
  ),
  'flowplayer' => 
  array (
    'product_id' => 'flowplayer',
    'is_core' => '0',
    'title' => 'Flowplayer',
    'description' => 'Video Player for the Web',
    'version' => '3.1',
    'latest_version' => NULL,
    'last_check' => '1371001287',
    'is_active' => '1',
    'url' => NULL,
    'url_version_check' => NULL,
  ),
  'popcliqs' => 
  array (
    'product_id' => 'popcliqs',
    'is_core' => '0',
    'title' => 'Popcliqs',
    'description' => 'Popcliqs Events',
    'version' => '1.028',
    'latest_version' => NULL,
    'last_check' => '1368964130',
    'is_active' => '1',
    'url' => 'http://www.popcliqs.com',
    'url_version_check' => 'http://www.popcliqs.com/version.php',
  ),
); ?>