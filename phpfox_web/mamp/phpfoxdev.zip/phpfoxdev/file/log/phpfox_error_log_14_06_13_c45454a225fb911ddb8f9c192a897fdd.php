<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:21:"Undefined index: time";s:9:"backtrace";s:724:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 815,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 408,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/phpfox/phpfox.class.php',
    'line' => 1157,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/index.php',
    'line' => 42,
  ),
)";s:7:"request";s:638:"array (
  'do' => '/popcliqsevents/',
  't' => '9',
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmb' => '111872281.1.10.1371214245',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17visit' => '1371213842',
  'PHPSESSID' => '39adf4ddccd2821ddb0d1ccf0c88200b',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:19:"Undefined index: ti";s:9:"backtrace";s:724:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 815,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 408,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/phpfox/phpfox.class.php',
    'line' => 1157,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/index.php',
    'line' => 42,
  ),
)";s:7:"request";s:664:"array (
  'do' => '/popcliqsevents/',
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmb' => '111872281.1.10.1371214245',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371214759',
  'core1d17visit' => '1371213842',
  'PHPSESSID' => '39adf4ddccd2821ddb0d1ccf0c88200b',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:19:"Undefined index: ti";s:9:"backtrace";s:724:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 815,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 408,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/phpfox/phpfox.class.php',
    'line' => 1157,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/index.php',
    'line' => 42,
  ),
)";s:7:"request";s:664:"array (
  'do' => '/popcliqsevents/',
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmb' => '111872281.1.10.1371214245',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371214759',
  'core1d17visit' => '1371213842',
  'PHPSESSID' => '39adf4ddccd2821ddb0d1ccf0c88200b',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:19:"Undefined index: ti";s:9:"backtrace";s:724:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 815,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/module/module.class.php',
    'line' => 408,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/phpfox/phpfox.class.php',
    'line' => 1157,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/index.php',
    'line' => 42,
  ),
)";s:7:"request";s:664:"array (
  'do' => '/popcliqsevents/',
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmb' => '111872281.1.10.1371214245',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371214759',
  'core1d17visit' => '1371213842',
  'PHPSESSID' => '39adf4ddccd2821ddb0d1ccf0c88200b',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
