<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:122:"unlink(/Applications/MAMP/tmp/php/win-test.txt) [<a href='function.unlink'>function.unlink</a>]: No such file or directory";s:9:"backtrace";s:705:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/file/file.class.php',
    'line' => 653,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/session/handler/file.class.php',
    'line' => 66,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/init.inc.php',
    'line' => 137,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 40,
  ),
)";s:7:"request";s:696:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1371970701',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:62:"Query Error:Table 'popcliqs.phpfox_phpfox_event' doesn't exist";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 171,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=143',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372016941',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:62:"Query Error:Table 'popcliqs.phpfox_phpfox_event' doesn't exist";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 171,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=143',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372016941',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:158:"Query Error:You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 171,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=142',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372016941',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:158:"Query Error:You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 171,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=142',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372016941',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:158:"Query Error:You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 171,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=142',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372016941',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:158:"Query Error:You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 171,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=142',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372016941',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:158:"Query Error:You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 171,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=142',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372016941',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:158:"Query Error:You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 172,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=138',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372017867',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:158:"Query Error:You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1";s:9:"backtrace";s:923:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/error/error.class.php',
    'line' => 95,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/database/dba.class.php',
    'line' => 747,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/popcliqsevents/include/component/ajax/ajax.class.php',
    'line' => 172,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:728:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.deleteIntEvent',
    'security_token' => '4d44f0fe9b5bc3667006ff55a2736ce4',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  'user_id' => '1event_id=142',
  'phpfoxuser_id' => '1',
  'phpfoxuser_hash' => 'd09c6f38deec5835e5bf1c8201186d0ad1e6eaa381327e8f14',
  'corea23cuser_id' => '1',
  'corea23cuser_hash' => '93faef95281591e31ed97fd40736eeb6b8c25dd9bd6cd0cef5',
  'core1d17user_id' => '1',
  'core1d17user_hash' => 'c5354ace34734ca09dbd567c1837fbae4d15e3f4a31015a46e',
  'PHPSESSID' => '862d22669f018cead8153beca7949ce9',
  'core1d17visit' => '1371970701',
  'core1d17last_login' => '1372017867',
)";s:2:"ip";s:3:"::1";}##
