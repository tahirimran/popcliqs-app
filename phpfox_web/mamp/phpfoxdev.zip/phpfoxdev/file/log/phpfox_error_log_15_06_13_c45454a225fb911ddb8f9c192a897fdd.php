<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:184:"unlink(/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/file/cache/ad_1.php) [<a href='function.unlink'>function.unlink</a>]: No such file or directory";s:9:"backtrace";s:1107:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/cache/storage/file.class.php',
    'line' => 311,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/cache/storage/file.class.php',
    'line' => 338,
  ),
  2 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/cache/storage/file.class.php',
    'line' => 132,
  ),
  3 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/module/ad/include/service/ad.class.php',
    'line' => 282,
  ),
  4 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/phpfox/phpfox.class.php',
    'line' => 1197,
  ),
  5 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/index.php',
    'line' => 42,
  ),
)";s:7:"request";s:509:"array (
  'do' => '/popcliqsevents/',
  'ti' => '24',
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:29:"Undefined variable: st_evt_hr";s:9:"backtrace";s:350:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:832:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.fetchIntEvent',
    'security_token' => '4440165346cbe634011f4968b269af29',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371287481',
  'core1d17visit' => '1371284657',
  'PHPSESSID' => '324bfaf9b0d8d7220e478e0b30986ff6',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:29:"Undefined variable: st_evt_hr";s:9:"backtrace";s:350:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:832:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.fetchIntEvent',
    'security_token' => '4440165346cbe634011f4968b269af29',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371287481',
  'core1d17visit' => '1371284657',
  'PHPSESSID' => '324bfaf9b0d8d7220e478e0b30986ff6',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:29:"Undefined variable: st_evt_hr";s:9:"backtrace";s:350:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:832:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.fetchIntEvent',
    'security_token' => '4440165346cbe634011f4968b269af29',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371287481',
  'core1d17visit' => '1371284657',
  'PHPSESSID' => '324bfaf9b0d8d7220e478e0b30986ff6',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:27:"Undefined index: start_date";s:9:"backtrace";s:350:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:832:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.fetchIntEvent',
    'security_token' => '4440165346cbe634011f4968b269af29',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371289283',
  'core1d17visit' => '1371284657',
  'PHPSESSID' => '324bfaf9b0d8d7220e478e0b30986ff6',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:27:"Undefined index: start_date";s:9:"backtrace";s:350:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:832:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.fetchIntEvent',
    'security_token' => '4440165346cbe634011f4968b269af29',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371289283',
  'core1d17visit' => '1371284657',
  'PHPSESSID' => '324bfaf9b0d8d7220e478e0b30986ff6',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
<?php defined('PHPFOX') or exit('NO DICE!');  ?>##
a:4:{s:7:"message";s:27:"Undefined index: start_date";s:9:"backtrace";s:350:"array (
  0 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/include/library/phpfox/ajax/ajax.class.php',
    'line' => 183,
  ),
  1 => 
  array (
    'file' => '/Users/tahirimran/Tahir /Development/popcliq/phpfox/svn/phpfox_dev/mamp/phpfoxdev/static/ajax.php',
    'line' => 186,
  ),
)";s:7:"request";s:832:"array (
  'core' => 
  array (
    'ajax' => 'true',
    'call' => 'popcliqsevents.fetchIntEvent',
    'security_token' => '4440165346cbe634011f4968b269af29',
    'is_admincp' => '0',
    'is_user_profile' => '0',
    'profile_user_id' => '0',
  ),
  '__utma' => '111872281.1635466517.1370120428.1370640026.1371214245.6',
  '__utmz' => '111872281.1370120428.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
  'core1d17last_login' => '1371289283',
  'core1d17visit' => '1371284657',
  'PHPSESSID' => '324bfaf9b0d8d7220e478e0b30986ff6',
  'core1d17user_hash' => '6b69fe9b8573706a04482d6acfe08bee197b25894749ec711d',
  'core1d17user_id' => '1',
  'corea23cuser_hash' => 'f5483e913b7e293ab04c752cc223f80bceda97c36f640c9d1e',
  'corea23cuser_id' => '1',
  'wp-settings-1' => 'editor=tinymce',
  'wp-settings-time-1' => '1361016397',
)";s:2:"ip";s:3:"::1";}##
