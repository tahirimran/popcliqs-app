<div id="popuppref" class="popup">
	<div class="top">
    	<span><h2>Prefererred Categories</h2></span>
		<a id="popupprefClose"  class="popupClose"><img src="./module/popcliqsevents/static/image/close_btn1.png" border="0" alt="Close" width="24" height="25"></a>
        </div>
    <div class="foArea">
	    <script type="text/javascript">
		$("ul:first").dragsort();
	</script>
	
    <div class="rightBox">
    <div class="foRight">
	<ul id="list2">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wouldnít Miss!
		<li><div style="background-color:#fbe9e9"></div></li>
    </ul>
        
 	<ul id="list2">
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Why Not!
		<li><div style="background-color:#fbfbe9"></div></li>
	</ul>
    <ul id="list2">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sounds Like Fun!
    	<li><div style="background-color:#eafbe9"></div></li>
	</ul>
	</ul>
	</div>
    </div>
    
    <div class="leftBox">
	<div class="foLeft">
	<ul id="list1">
		<li><div>Sports/Fitness</div></li>
		<li><div>Professional</div></li>
		<li><div>Education</div></li>
		<li><div>Support Group</div></li>
		<li><div>Arts & Socials</div></li>
		<li><div>Outdoor & Adventure</div></li>
        <li><div>Scheduled Event</div></li>
        <li><div>Other</div></li>
	</ul>
    </div>
    </div>
	   <div class="cBox">
       
       <li><input type="checkbox" name="checkbox" id="checkbox" /> Default ZIP</li>
       <li><input type="checkbox" name="checkbox" id="checkbox" /> Home ZIP</li>
       <li><input type="checkbox" name="checkbox" id="checkbox" /> Others</li>
       
	<div class="foLeft"></div>        
	<div class="foRight">
    <input name="textfield" type="text" id="textfield" value="Specific Key enter here" class="text" />
    </div><br><br><br><br><br><br><br><br>
 <div class="foLeft"><img src="./module/popcliqsevents/static/image/save_btn.png" align="left" alt="btn" width="112" height="46" border="0"></div>       
	</div>
        
       </div>   
</div> <!-- end of popuppref -->
<div id="popuphistory" class="popup">
    <div class="top">
    	<span><h2>History</h2></span>
		<a id="popuphistoryClose" class="popupClose"><img src="./module/popcliqsevents/static/image/close_btn1.png" border="0" alt="Close" width="24" height="25"></a>
        </div>
        
        <div class="foArea">
<div id="TabbedPanels1" class="TabbedPanels">
  <ul class="TabbedPanelsTabGroup">
    <li class="TabbedPanelsTab" tabindex="0">Attended</li>
    <li class="TabbedPanelsTab" tabindex="0">Initiated</li>
  </ul>
  <div class="TabbedPanelsContentGroup">
    <div class="TabbedPanelsContent">
<table width="100%" border="0" cellspacing="2" cellpadding="8">
        <tr>
          <td width="16%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Date</td>
          <td width="44%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Event Desc</td>
          <td width="25%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Maybes</td>
          <td width="15%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Activities</td>
        </tr>
        <tr>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
        </tr>
        <tr>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
        </tr>
        <tr>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">&nbsp;</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">&nbsp;</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">&nbsp;</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">&nbsp;</td>
        </tr>
        <tr>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">&nbsp;</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">&nbsp;</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">&nbsp;</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">&nbsp;</td>
        </tr>
      </table>    </div>
      
      
    <div class="TabbedPanelsContent"><table width="100%" border="0" cellspacing="2" cellpadding="8">
        <tr>
          <td width="16%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Date</td>
          <td width="34%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Event Desc</td>
          <td width="20%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Maybes</td>
          <td width="20%" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Activities</td>
          <td width="25%" height="35" align="left" valign="middle" bgcolor="#009BCE" style="color:#FFF; font-weight:bold">Action</td>
        </tr>
        <tr>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
        </tr>
        <tr>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
          <td align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#C1EBFF">Sample Text</td>
        </tr>
        <tr>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
          <td height="25" align="left" valign="middle" bgcolor="#8CDAFF">Sample Text</td>
        </tr>

      </table></div>
  </div>
</div>
<script type="text/javascript">
<!--
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
//-->
</script>
 </div>   
        </div><!-- end of popuphistory -->
<div id="popupnewevent" class="popup">
    <div class="top">
    	<span><h2>Create a New Event</h2></span>
		<a id="popupneweventClose" class="popupClose"><img src="./module/popcliqsevents/static/image/close_btn1.png" border="0" alt="Close" width="24" height="25"></a>
        </div>
        <div class="foArea">

    <!-- Form Code Start -->
<form id='contactus'>

<fieldset >

<div class='formcontainer'>
    <label for='message' >Event Description :</label>
    <textarea rows="5" cols="40" name='message' id='message'></textarea>
</div>

<div class='formcontainer'>
    <label for='name' >Category : </label>
    <select name="select" id="select">
    <option>All</option>
  	<option>Category 1</option>
    <option>Category 2</option>
    <option>Category 3</option>
    <option>Category 4</option>
    <option>Category 5</option>
    </select>
</div>
<div class='formcontainer'>
    <label for='email' >Location :</label>
    <input type='text' name='email' id='email' value='Address/Venue' maxlength='50' />

    <select name="select" id="select">
    <option>City</option>
  	<option>City Name 1</option>
    <option>City Name 2</option>
    <option>City Name 3</option>
    <option>City Name 4</option>
    <option>City Name 5</option>
    </select>
    
    <select name="select" id="select">
    <option>State</option>
  	<option>State Name 1</option>
    <option>State Name 2</option>
    <option>State Name 3</option>
    <option>State Name 4</option>
    <option>State Name 5</option>
    </select>
    
    <label></label>
    <div class="leftPadding130"><input type='text' name='email' id='email' value='ZIP Code' maxlength='50' /></div>
    
    <select name="select" id="select">
    <option>Age Limit</option>
  	<option>Age Limit 1</option>
    <option>Age Limit 2</option>
    <option>Age Limit 3</option>
    <option>Age Limit 4</option>
    <option>Age Limit 5</option>
    </select>
    
    <label></label>
    <div class="leftPadding130"><input type='text' name='email' id='email' value='Set Attendance Limit' maxlength='50' /></div>
</div>
<div class='formcontainer'>
    <label for='message' >Message :</label>
    <textarea rows="10" cols="50" name='message' id='message'></textarea>
</div>

<div class='formcontainer'>
	<div align="right" style="padding-left: 283px"><img src="./module/popcliqsevents/static/image/go_btn.png" align="left" alt="btn" width="112" height="46" border="0"></div>
    
</div>

</fieldset>
</form>
	
	   
        
       </div>   
	
  
        
        </div><!-- end of popupnewevent -->
<div id="popupeventdetails" class="popup">
<div class="top">
    	<span><h2>Event Details</h2></span>
		<a id="popupeventdetailsClose" class="popupClose"><img src="./module/popcliqsevents/static/image/close_btn1.png" border="0" alt="Close" width="24" height="25"></a>
        </div>
        <div class="foArea">

    <!-- Form Code Start -->
<form id='contactus'>

<fieldset >

<div class='container1'>
    <textarea rows="5" cols="40" name='message' id='message'></textarea>
</div>

<div class='formcontainer'>
    <label for='email' >Category :</label>
    <input type='text' name='email' id='email' value='Sports' maxlength='50' />
</div>
<div class='formcontainer'>
    <label for='email' >Location :</label>
    <input type='text' name='email' id='email' value='Wildwood Ridge, Powers Ferry Rd, Atlanta' maxlength='50' />
</div>
<div class='formcontainer bottomSpace'>
</div>

<div class='formcontainer'>
	<div align="right" style="padding-left: 165px"><img src="./module/popcliqsevents/static/image/pop_this_event_btn.png" align="left" alt="btn" width="231" height="46" border="0"></div>
    
</div>

</fieldset>
</form>
 </div>   
<!-- save sort order here which can be retrieved on server on postback -->
<input name="list1SortOrder" type="hidden" />
	
        
  
        
        </div><!-- end of popupeventdetails -->
<canvas width="960" height="650" style="position:relative;top:-8px;" id="mainCanvas"></canvas>
